package com.smtw.common.exception;

public class AccessException extends RuntimeException{
	
	public AccessException(String msg) {
		super(msg);
	}
}
